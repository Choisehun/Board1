package Util;

public class Pr {
	private static final String Dot = "🐈‍";
	private static final int Line_Length = 39;
	private static final int space = 0;
	



	public static void p(String s) {
		System.out.print(s);
	}//Sysout 출력
	
	public static void pn(String s) {
		System.out.println(s);
	}//Sysoutln 출력
	
	public static void pn() {
		System.out.println();
	}

	
	
	
	public static void Dot() {
		System.out.print(Dot);
	}
	
	
	public static void Line() {
		for(int i=0; i<Line_Length; i++) {
			p(Dot);
		}
		pn(); //p(DOt)가 끝나면 줄바꿈
		
		
	}//Line
	
	public static void space(int c) {
		for(int i=0; i<c; i++) {
			System.out.print(" ");
		}
	}
	
	
	
}
