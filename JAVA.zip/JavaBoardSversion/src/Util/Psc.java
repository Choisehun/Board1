package Util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Psc {
	//입력을 담당하는 util
	static Scanner sc = new Scanner(System.in);
	static BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
	
	static public String r(String comment) {
		Pr.p(comment+":");
		return sc.next();
		
	}
	public static String r() {
		return sc.next();
	}
	
	static public String r1(String comment) {
		Pr.p(comment+":");
		try {
			return reader.readLine();
		}catch(IOException e) {
			e.printStackTrace();
			return null;
			
		}
	}
	
	
}
