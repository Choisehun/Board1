package com.data;

import java.time.LocalDate;


import Util.Pr;


public class Post {
	static public int no=0;
	public String title;
	public String content;
	public String writer;
	public int hit;
	public String date;
	public int instanceNo = 0;
	
	
	public Post(String title, String content, String writer, int hit) {
		no=no+1;
		instanceNo = no;
		this.title = title;
		this.content = content;
		this.writer = writer;
		this.hit = hit;
		LocalDate now = LocalDate.now();
		date = now.toString();
	}



	public void info() {
		Pr.p("글제목: "+title);
		Pr.p("작성자: "+writer);
		Pr.pn("글내용:"+content);
		Pr.pn("조회수:"+hit);
	}
	
	public void infoList() {
		Pr.pn("글번호: " + instanceNo+" 글제목:"+title);
	}
	
	
	
	public void infoRead() {
		Pr.pn("글제목:"+title);
		Pr.pn("글내용:"+content);
		Pr.pn("작성자:"+writer);
		Pr.pn("조회수:"+hit);
		Pr.pn("작성일 : " + date);
	}
	
}
