package com.main.s.board;


import com.data.Data;

import Display.Dis;
import Util.Pr;

public class Board {

	
	
	void run() {
		Data.loadData();
		Dis.title();
		//Dis.MainMenu();
		Pr.pn();
		ProMenu.run();
		
		
	}
}
