package com.main.s.board;

import Display.Dis;
import Util.Pr;
import Util.Psc;

public class ProMenu {
	
	static void run() {
		loop:
		while(true) {
			Dis.MainMenu();
			System.out.println();
			String cmd = Psc.r("선택");
			switch(cmd) {
			case "1" : //글리스트
				ProMenuList.run();
				break;
				
			case "2" : //글읽기
				ProMenuRead.run();
				break;
				
			case "3" ://글쓰기
				ProMenuWrite.run();
				break;
				
			case "4" ://글삭제
				ProMenuDel.run();
				break;
				
			case "x" : //종료
				System.out.println("돌아가기");
				break loop;
				
				default:
					Pr.pn("잘못입력함");
					break;
				
			}
		}
	}

}
