package com.main.s.board;

import com.data.Data;
import com.data.Post;

import Util.Pr;

public class ProMenuRead  {

	public static void run() {
		
		
		
		
		
		
		for(Post p:Data.posts) {
			p.infoRead();
		}
		
	}

}
