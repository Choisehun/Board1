package com.main.s.board;

import com.data.Data;
import com.data.Post;

import Util.Pr;
import Util.Psc;

public class ProMenuDel  {
	public static void run() {
		
		String cmd = Psc.r("정말 삭제 하시겠습니까? [1.Y 2.N]");
		yy:switch(cmd) {
		case "1":
			if(Data.posts != null) {
				Data.posts.clear();
				Pr.pn("삭제했습니다.");
			}
			break;
		case "2":
			Pr.pn("취소");
			break yy;
			
		}
		
		
		
		
		
		
		
		}

	

}
