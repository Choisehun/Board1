package com.main.s.board;


import com.data.Data;
import com.data.Post;


import Util.Pr;
import Util.Psc;

public class ProMenuWrite {
	
	public static void run() {
		
		Pr.pn("                               글을쓰세요");
		String title;
		
		while(true) {
			title=Psc.r1("글제목");
			if(title.length()>0) {
				break;
			}else {
				Pr.pn("다시입력하세요");
			}
		}//while
		
		String content;
		
		while(true) {
			content=Psc.r1("글내용");
			if(content.length()>0) {
				break;
			}else {
				Pr.pn("다시입력하세요");
			}
		}//while
		
		String writer;
		
		while(true) {
			writer=Psc.r("작성자");
			if(writer.length()>0) {
				break;
			}else {
				Pr.pn("다시입력하세요");
			}
		}//while
		
		Post p = new Post(title, content, writer ,0);
		Data.posts.add(p);
		Pr.pn("글 작성됨");
	}
}
