package com.main.s.board;

import Util.Pr;

public class Main {
	public static void main(String[] args) {
		
		Board Menu = new Board();
		Menu.run();
		
		
	}
}
