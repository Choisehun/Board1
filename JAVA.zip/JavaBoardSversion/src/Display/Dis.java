package Display;

import Util.Pr;

public class Dis {
	
	
	public static void title() {
		Pr.Line();
		Pr.Dot();
		Pr.space(70);
		Pr.Dot();
		System.out.println();
		System.out.println("🐈‍                             "+"고양이 카페 입니다                              🐈‍");
		Pr.Dot();
		Pr.space(70);
		Pr.Dot();
		Pr.pn();
		Pr.Line();
		
	}
	
	public static void MainMenu() {
		Pr.p("                   [1.글리스트 2.글 읽기 3.글쓰기 4.글삭제 x.종료]");
	}
}
