package com.main.s.board;

import com.data.Data;
import com.data.Post;

import Util.Pr;

public class ProMenuList {
public static void run() {
	
	
	
	
		for(Post P:Data.posts) {
			P.infoList();
		}

		
			Pr.pn("저장된 내용 갯수:"+Data.posts.size());
			
			
		
			
	}


}
