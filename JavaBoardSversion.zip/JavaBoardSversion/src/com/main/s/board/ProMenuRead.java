package com.main.s.board;

import com.data.Data;
import com.data.Post;

import Util.Pr;
import Util.Psc;

public class ProMenuRead  {

	public static void run() {
		
		
		
		
		
		
		for(Post p:Data.posts) {
			
			String cmd = Psc.r("읽을 글 번호");
			if(cmd.equals(p.instanceNo+"")) {
				p.infoRead();
				p.hit = p.hit+1;
			}
			
			
			
			
			
			
		}
		
	}

}
