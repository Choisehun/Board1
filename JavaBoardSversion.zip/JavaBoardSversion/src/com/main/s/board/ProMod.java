package com.main.s.board;

import com.data.Data;
import com.data.Post;

import Util.Pr;
import Util.Psc;

public class ProMod {

	public static void run() {
	
		Pr.pn("수정");
		
		String cmd = Psc.r("수정할 글 번호");
		for(Post P:Data.posts) {
			
			if(cmd.equals(P.instanceNo+"")) {
				
				
//				System.out.println("완료");
//				
//				String content=Psc.r1("수정내용");
//				P.content = content;
//		
//				System.out.println("완료");
				
				
				
				loop:
				while(true) {
					
						cmd = Psc.r("1.제목, 2.내용 3.작성자 x.뒤로가기");
					switch(cmd) {
					case "1":
						String title=Psc.r1("제목 수정");
						P.title = title;
						System.out.println("완료");
						break ;
						
					case "2":
						String content=Psc.r1("내용 수정");
						P.content = content;
						System.out.println("완료");
						break ;
						
						
					case "3":
						String writer=Psc.r1("작성자 수정");
						P.writer = writer;
						System.out.println("완료");
						break loop;
						
					case "x":
						System.out.println("나가기");
						break loop;
						
				
					}//switch
				}
				
				P.dates();
		
			}//if
		
			
		}//for
	}
}
