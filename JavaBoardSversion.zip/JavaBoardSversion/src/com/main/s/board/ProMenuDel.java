package com.main.s.board;

import com.data.Data;
import com.data.Post;

import Util.Pr;
import Util.Psc;

public class ProMenuDel {
	public static void run() {

		String cmd = Psc.r("[1.전체 삭제 2.삭제 번호 선택 3. 뒤로 가기]");
		System.out.println();
		yy: switch (cmd) {
		case "1":
			int ct = Data.posts.size();
			for (int i = 0; i < ct; i++) {
				Data.posts.remove(0);

			} // case1 for
			Pr.pn("전체삭제");
			break yy;

		case "2":

			int searchNumb = 0;

//			cmd = Psc.r ("몇번 게시물 삭제");
//			for(int i=0; i<Data.posts.size(); i++) {
//				if(cmd.equals(Data.posts.get(i).instanceNo+"" )) {
//					cmd = Psc.r("비밀 번호를 입력 하세요");
//				 if(cmd.equals("123")) {
//						Data.posts.remove(i);
//						System.out.println("삭제완료");
//					}else {
//						System.out.println("비밀번호를 다시 입력하세요");
//						
//					}
//				}
//			}

			cmd = Psc.r("몇번 게시물 삭제");
			for (int i = 0; i < Data.posts.size(); i++) {
				if (cmd.equals(Data.posts.get(i).instanceNo + "")) {
					searchNumb = i;
				}
			}

			cmd = Psc.r("비밀번호를 입력하세요 ");
			if (cmd.equals("123")) {
				Data.posts.remove(searchNumb);
				System.out.println("삭제완료");
			} else {
				System.out.println("다시입력하세요");
				 
			}

//			Post nom = null;
//			
//			for(Post p:Data.posts) {
//				cmd = Psc.r ("몇번 게시물 삭제");
//				
//					nom = p;
//					
//					
//				}//if
//				
//			
//			}//case2 for
//			Data.posts.remove(p);
//			
			break;

		case "3":
			System.out.println("취소했습니다");
			Pr.pn();
			break yy;

		}// yy:swtich

	}

	private static Object instanceNo() {
		// TODO Auto-generated method stub
		return null;
	}

}
